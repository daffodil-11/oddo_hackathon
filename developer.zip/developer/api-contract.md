# API Contract

Base URL: `/api`

## Health

`GET /health`

Returns `{ status, service, timestamp }`.

## Dashboard

`GET /dashboard?role=hr`

Returns KPI stats, weekly changes, and department health.

## Employees

`GET /employees?search=&department=&page=1&pageSize=20`

Returns `{ data, page, pageSize, total }`. Use pagination in the employee table.

## Attendance and leave

`GET /attendance`

`GET /leave`

`PATCH /leave/:id` with `{ "status": "Approved" | "Rejected" }`.

## Intelligence

`GET /insights`

Returns attendance anomaly, workload, wellbeing, and retention signals.

`POST /copilot` with `{ "question": "What changed this week?" }`.

`POST /pulse` with `{ "value": "Good" | "Okay" | "Struggling", "feedback": "optional" }`.

Production integrations should add authentication, request IDs, audit logging, rate limits, and server-side permission checks before exposing confidential employee or payroll data.
