const base = process.env.DAYFLOW_API_URL || 'http://localhost:4000/api'
const checks = [
  ['health', `${base}/health`],
  ['dashboard', `${base}/dashboard?role=hr`],
  ['employees', `${base}/employees?page=1&pageSize=5`],
  ['attendance', `${base}/attendance`],
  ['leave', `${base}/leave`],
  ['insights', `${base}/insights`]
]

let failed = false
for (const [name, url] of checks) {
  const response = await fetch(url)
  const body = await response.json()
  if (!response.ok) {
    failed = true
    console.error(`FAIL ${name}: ${response.status}`)
  } else {
    console.log(`PASS ${name}: ${Object.keys(body).join(', ')}`)
  }
}

if (failed) process.exitCode = 1
