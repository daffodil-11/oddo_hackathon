# Developer Setup

## Local development

1. Install Node.js 18 or newer.
2. From the project root, run `npm install`.
3. Install workspace packages with `npm --prefix backend install` and `npm --prefix frontend install`.
4. Run `npm run dev`.
5. Open `http://localhost:5173`.

The demo frontend is intentionally usable without the API. When the API is unavailable, it keeps its local demo data and shows an offline state rather than blocking the workspace.

## Environment

Copy `.env.example` to `.env` in the frontend when connecting to an API at a different origin. The backend accepts `PORT` and `FRONTEND_ORIGIN` from `backend/.env`.

## Production

Build the frontend with `npm run build`. Serve `frontend/dist` from a static host and run `npm start` for the API. Configure the static host to return `index.html` for the application routes.

## Roles

The demo supports `hr`, `manager`, and `employee`. Keep role checks in both the frontend route layer and the backend authorization middleware when replacing the mock API.
