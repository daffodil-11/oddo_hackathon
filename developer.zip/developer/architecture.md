# DAYFLOW Architecture

## Product loop

`Observe -> Detect -> Understand -> Recommend -> Act`

## Boundaries

- `frontend/` owns the responsive UI, role navigation, protected routes, and local fallback behavior.
- `backend/` owns HTTP transport, validation, pagination, and the future persistence boundary.
- `modules/` contains pure intelligence functions that can be unit-tested without a browser or database.
- `developer/` contains setup instructions, API contracts, and smoke checks.

## Reliability approach

- Dashboard data is treated as cacheable and safe to show stale during a temporary outage.
- API calls should use an abort timeout and bounded exponential retry when the mock API is replaced.
- Components should fail independently with a retry state; raw server errors should not be rendered.
- Employee tables are paginated and filtered before rendering.
- Risk signals are decision-support indicators, not guaranteed predictions or medical diagnoses.
