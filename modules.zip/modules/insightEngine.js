export function detectAttendanceSignals({ attendance = [], employees = [] } = {}) {
  const signals = []
  const rahul = employees.find(employee => employee.name === 'Rahul Sethi')
  if (rahul) signals.push({ level: 'Critical', title: 'Frequent absence detected', description: 'Rahul has been absent 6 times in the last 30 days.', subject: rahul.name, action: 'Review attendance pattern.' })
  const lateCount = attendance.filter(row => row.status === 'Late').length
  if (lateCount) signals.push({ level: 'Warning', title: 'Repeated late arrivals', description: 'Late arrivals are clustering above the team baseline.', subject: 'Marketing and Engineering', action: 'Review recent attendance trends.' })
  signals.push({ level: 'Information', title: 'Engineering attendance decreased by 12%', description: 'Attendance is down while leave usage is up 18%.', subject: 'Engineering department', action: 'Review department attendance and leave patterns.' })
  return signals
}

export function summarizeChanges() {
  return {
    attendance: { value: -8, direction: 'down' },
    leaveUsage: { value: 12, direction: 'up' },
    lateArrivals: { value: 6, direction: 'up' },
    employeeCount: { value: 4, direction: 'up' },
    mainConcern: 'Engineering attendance dropped significantly this week.'
  }
}

export function recommendAction(signal) {
  const actions = {
    absence: 'Review the employee attendance pattern with their manager.',
    lateness: 'Review recent attendance trends and schedule a check-in.',
    workload: 'Review workload distribution and overtime.',
    wellbeing: 'Schedule a manager check-in and listen for context.',
    leave: 'Review department leave trends before adjusting coverage.'
  }
  return actions[signal] || 'Review the supporting data and choose a proportionate next step.'
}
