export function retentionRisk({ attendanceChange = -8, engagementChange = -14, workloadChange = 18 } = {}) {
  const score = Math.abs(attendanceChange) + Math.abs(engagementChange) + Math.abs(workloadChange)
  const level = score > 30 ? 'High' : score > 15 ? 'Medium' : 'Low'
  return { label: 'Retention Risk Signal', level, explanation: 'Recent attendance change + reduced engagement + increased workload.', action: 'Consider a manager check-in.' }
}

export function workloadRisk({ averageHoursChange = 18, overtime = true } = {}) {
  return { label: 'Workload Risk Detected', severity: averageHoursChange > 15 ? 'Warning' : 'Information', explanation: `Team average working hours increased ${averageHoursChange}% over the last three weeks.`, signals: ['Working hours', overtime ? 'Overtime' : 'Leave usage'], actions: ['Review workload', 'Check overtime', 'Encourage appropriate leave'] }
}

export function wellbeingWarning({ attendanceDown = true, leaveUp = true, pulseDown = true, workloadUp = true } = {}) {
  const signals = [attendanceDown && 'Attendance ↓', leaveUp && 'Leave ↑', pulseDown && 'Employee pulse ↓', workloadUp && 'Workload ↑'].filter(Boolean)
  return { label: 'Potential wellbeing concern detected', severity: signals.length >= 3 ? 'Critical' : 'Warning', signals, explanation: 'Multiple workforce signals are moving in the same direction.', action: 'Schedule a manager check-in.' }
}
